case class Tranasction(account_id:String,amount:Double,status:String)

sealed trait Stream{
  val timestamp:Long = 1234
}

case class Stream1(location:String, accountId:String, enrichedAccountId:String, linesofBusinesses:String, accountLife:Int, override val timestamp:Long) extends Stream

case class Stream2(location:String,accountId:String,enrichedAccountId:String,linesofBusinesses:String,accountLife:Int,override  val timestamp:Long) extends Stream