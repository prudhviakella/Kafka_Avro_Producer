//import java.time.Duration
//import java.util.Properties
//
//
//import org.apache.flink.streaming.api.scala._
//import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
//import org.apache.flink.streaming.api.TimeCharacteristic
//import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks
//import org.apache.flink.streaming.api.watermark.Watermark
//
//
//
//
//object SimpleFlinkJob {
//
//  def main(args: Array[String]) {
//
//    val schemaRegistryUrl = "http://localhost:8081/"
//    val properties = new Properties()
//    properties.setProperty("bootstrap.servers", "localhost:9092")
//    properties.setProperty("group.id", "test")
//    val env = StreamExecutionEnvironment.getExecutionEnvironment
//    env.getConfig.disableForceKryo()
//    env.getConfig.enableForceAvro()
//    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
//    //env.getConfig.disableGenericTypes()
//
//
//    val Transactions1 = env.addSource(new FlinkKafkaConsumer(
//      "Transaction6",new KafkaGenricDeserialzer("C:\\Users\\pakella\\IdeaProjects\\Avro_Flink_Consumer\\Transaction.avsc"),properties).setStartFromEarliest())
//      .assignTimestampsAndWatermarks(new TimestampExtractor())
//
//    Transactions1.print()
////    val trans1_map = Transactions1.map(elem=>{
////      val splitarr = elem.split(":")
////      Tranasction(splitarr(0),splitarr(1).toDouble,splitarr(2))
////    })
////    trans1_map.print()
////
////    val Transactions2 = env.addSource(new FlinkKafkaConsumer(
////      "Transaction5",new KafkaGenricDeserialzer(),properties).setStartFromEarliest())
////      .assignTimestampsAndWatermarks(new TimestampExtractor())
////
////    val trans2_map = Transactions2.map(elem=>{
////      val splitarr = elem.split(":")
////      Tranasction(splitarr(0),splitarr(1).toDouble,splitarr(2))
////    })
////    trans2_map.print()
//////
////    trans1_map.join(trans2_map)
////      .where(eleme => eleme.account_id)
////      .equalTo(elem => elem.account_id)
////      .window(TumblingEventTimeWindows.of(Time.milliseconds(1000)))
////      .apply((e1,e2)=>e1.amount+e2.amount)
////      .print()
//    env.execute("Avro Serialization/Deserialization using Confluent Registry Example")
//
//  }
//}