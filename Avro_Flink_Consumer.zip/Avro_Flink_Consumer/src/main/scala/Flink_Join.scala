import java.time.Duration
import java.util.Properties

import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time



object Flink_Window_Join {
  def main(args: Array[String]) {
    val Avro_Schema_Stream1_Location = "C:\\Users\\pakella\\IdeaProjects\\Avro_Flink_Consumer\\Transaction.avsc"
    val Avro_Schema_Stream2_Location = "C:\\Users\\pakella\\IdeaProjects\\Avro_Flink_Consumer\\Transaction.avsc"
    val Stream1_Topic = "Transaction6"
    val Stream2_Topic = "Transaction5"

    val properties = new Properties()
    properties.setProperty("bootstrap.servers", "localhost:9092")
    properties.setProperty("group.id", "test")

    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.getConfig.disableForceKryo()
    env.getConfig.enableForceAvro()
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)

    val Stream1 = env.addSource(new FlinkKafkaConsumer(
      Stream1_Topic,new KafkaGenricDeserialzer(Avro_Schema_Stream1_Location,"Stream1"),properties).setStartFromEarliest())
      .assignTimestampsAndWatermarks(new TimestampExtractor())

    Stream1.print()


//    val Stream2 = env.addSource(new FlinkKafkaConsumer(
//      Stream2_Topic,new KafkaGenricDeserialzer(Avro_Schema_Stream2_Location,"Stream2"),properties).setStartFromEarliest())
//      .assignTimestampsAndWatermarks(new TimestampExtractor())


//    Stream1.join(Stream2)
//      .where(eleme => eleme.accountId)
//      .equalTo(elem => elem.accountId)
//      .window(TumblingEventTimeWindows.of(Time.milliseconds(1000)))
//      .apply((e1,e2)=>e1.accountLife+e2.accountLife)
//      .print()

    env.execute("Flink Join")

  }
}