import java.io.File

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import org.apache.avro.generic.GenericRecord
import org.apache.avro.io.{BinaryDecoder, DecoderFactory}
import org.apache.avro.specific.SpecificDatumReader
import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.api.java.typeutils.TypeExtractor
import org.apache.flink.streaming.connectors.kafka.KafkaDeserializationSchema
import org.apache.kafka.clients.consumer.ConsumerRecord

class KafkaGenricDeserialzer_Stream2(val Schema_location:String) extends KafkaDeserializationSchema[Stream2]{
  override def isEndOfStream(nextElement: Stream2): Boolean = false
  override def deserialize(record: ConsumerRecord[Array[Byte], Array[Byte]]): Stream2 = {
    //Creating Parser Object to parse the avro schema
    val schemaParser = new Parser
    //Parse method in Parser Class will parse the schemaJson string and returns back Schema object
    //val valueSchemaAvro:Schema = schemaParser.parse(valueSchemaJson)
    val valueSchemaAvro:Schema = schemaParser.parse(new File(Schema_location))
    //De-serializing the Array[Byte] Message value to Generic record
    // Interface GenericRecord A generic instance of a record schema
    val reader:SpecificDatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](valueSchemaAvro)
    //Decoding the Byte Array Record
    val decoder:BinaryDecoder = DecoderFactory.get().binaryDecoder(record.value(),null)
    //Generic Record  object is created
    val transactiondata:GenericRecord = reader.read(null,decoder)
    //Extracting Record fields and creating a String Object as an Output
      Stream2(
        transactiondata.get("location").toString,
        transactiondata.get("accountId").toString,
        transactiondata.get("enrichedAccountId").toString,
        transactiondata.get("linesofBusinesses").toString,
        transactiondata.get("accountLife").toString.toInt, record.timestamp()
      )
  }
  override def getProducedType: TypeInformation[Stream2] = TypeExtractor.getForClass(classOf[Stream2])
}
