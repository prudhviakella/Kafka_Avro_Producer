import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks
import org.apache.flink.streaming.api.watermark.Watermark

class TimestampExtractor extends AssignerWithPeriodicWatermarks[Stream] {
  override def extractTimestamp(e:Stream , prevElementTimestamp: Long) = {
    //     print(System.currentTimeMillis)
    e.timestamp
  }
  override def getCurrentWatermark(): Watermark = {
    new Watermark(System.currentTimeMillis)
  }
}

class TimestampExtractor_Stream2 extends AssignerWithPeriodicWatermarks[Stream2] {
  override def extractTimestamp(e:Stream2 , prevElementTimestamp: Long) = {
    //     print(System.currentTimeMillis)
    e.timestamp
  }
  override def getCurrentWatermark(): Watermark = {
    new Watermark(System.currentTimeMillis)
  }
}