import java.util.{Properties, UUID}

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericRecord
import org.apache.avro.specific.SpecificDatumWriter
import java.io.{ByteArrayOutputStream, File}

import org.apache.avro.io._
import org.apache.kafka.clients.producer.{KafkaProducer, Producer, ProducerConfig, ProducerRecord}

import scala.io.Source
object KafkaProducer extends App{
  private val props = new Properties()
  val kafkaBootstrapServer = "localhost:9092"
  props.put("bootstrap.servers", kafkaBootstrapServer)
  props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer")
  props.put("serializer.class", "kafka.serializer.DefaultEncoder")
  props.put("client.id", UUID.randomUUID().toString())
  private val producer = new KafkaProducer[String, Array[Byte]](props)
  val schemaParser = new Parser
  val valueSchemaAvro:Schema = schemaParser.parse(new File("C:\\Users\\pakella\\IdeaProjects\\Avaro_Kafka\\src\\Transaction.avsc"))

  // Create avro generic record object
  val genericUser: GenericRecord = new GenericData.Record(valueSchemaAvro)
  //Put data in that generic record
  genericUser.put("location", "loc")
  genericUser.put("accountId", "12345")
  genericUser.put("enrichedAccountId", "988")
  genericUser.put("linesofBusinesses", "hee")
  genericUser.put("accountLife",-122222222)
  // Serialize generic record into byte array
  val writer = new SpecificDatumWriter[GenericRecord](valueSchemaAvro)
  val out = new ByteArrayOutputStream()
  val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
  writer.write(genericUser, encoder)
  encoder.flush()
  out.close()
  val serializedBytes: Array[Byte] = out.toByteArray()
  val queueMessage = new ProducerRecord[String, Array[Byte]]("Transaction6", serializedBytes)
  val ack = producer.send(queueMessage).get()
  println(s"${ack.toString} written to partition ${ack.partition.toString}")
}